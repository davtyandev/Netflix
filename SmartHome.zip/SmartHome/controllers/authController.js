const db = require('../models');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require('../config/config.json');

// Function to authenticate a user and generate a JWT token
async function authenticateUser(login, password) {
    try {
        // Find the user with the provided login
        const user = await db.User.findOne({ where: { login } });

        if (!user) {
            throw new Error('User not found');
        }

        // Check if the provided password matches the stored hashed password
        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) {
            throw new Error('Invalid password');
        }

        // Generate a JWT token
        const authToken = jwt.sign({ userId: user.login }, config.jwtSecret, { expiresIn: '1h' });

        return authToken;
    } catch (error) {
        throw error;
    }
}

module.exports = {
    authenticateUser
};
