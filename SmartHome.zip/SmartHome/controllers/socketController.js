const db = require('../models');

// Function to get the list of sockets available to the user
async function getSocketList(userId) {
    try {
        // Find the user with the provided userId
        const user = await db.User.findByPk(userId);

        if (!user) {
            throw new Error('User not found');
        }

        // Get the list of sockets associated with the user through the many-to-many association
        const sockets = await user.getSockets();

        // Format the response data with the required fields (uuid and name)
        const socketList = sockets.map(socket => ({ uuid: socket.uuid, name: socket.name }));
        return socketList;
    } catch (error) {
        throw error;
    }
}

module.exports = {
    getSocketList
};
