const db = require('../models');
const bcrypt = require('bcrypt');

// Function to authorize a user
async function authorizeUser(login, password) {
    try {
        // Find the user with the provided login
        const user = await db.User.findOne({ where: { login } });

        if (!user) {
            throw new Error('User not found');
        }

        // Check if the provided password matches the stored hashed password
        const isPasswordValid = await bcrypt.compare(password, user.password);

        return isPasswordValid;
    } catch (error) {
        throw error;
    }
}

module.exports = {
    authorizeUser
};
