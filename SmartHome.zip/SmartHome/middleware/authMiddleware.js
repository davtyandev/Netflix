// authMiddleware.js

// Middleware function to check if the user is authenticated
const isAuthenticated = (req, res, next) => {
    // Check if the user is logged in (authenticated)
    if (req.isAuthenticated()) {
        // If the user is authenticated, allow them to proceed to the next middleware or route handler
        return next();
    } else {
        // If the user is not authenticated, redirect them to the login page or return an error
        return res.status(401).json({ message: 'Unauthorized. Please log in.' });
    }
};

// Middleware function to check if the user has specific permissions (authorization)
const hasPermission = (requiredPermission) => (req, res, next) => {
    // Check if the user has the required permission
    if (req.user && req.user.permissions && req.user.permissions.includes(requiredPermission)) {
        // If the user has the required permission, allow them to proceed to the next middleware or route handler
        return next();
    } else {
        // If the user does not have the required permission, return an error
        return res.status(403).json({ message: 'Forbidden. You do not have permission to access this resource.' });
    }
};

module.exports = {
    isAuthenticated,
    hasPermission,
};

/*const express = require('express');
const router = express.Router();
const { isAuthenticated, hasPermission } = require('../middleware/authMiddleware');

// Protected route that requires authentication
router.get('/protected', isAuthenticated, (req, res) => {
  res.json({ message: 'You have access to the protected route.' });
});

// Protected route that requires specific permission
router.get('/admin', isAuthenticated, hasPermission('admin'), (req, res) => {
  res.json({ message: 'You have access to the admin route.' });
});

module.exports = router;
*/

