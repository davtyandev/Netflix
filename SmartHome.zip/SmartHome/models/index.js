const Sequelize = require('sequelize');
const path = require('path');
const fs = require('fs');

// Load environment variables from .env file
require('dotenv').config();

// Database connection settings
const database = process.env.DB_NAME || 'your_database_name';
const username = process.env.DB_USERNAME || 'your_database_username';
const password = process.env.DB_PASSWORD || 'your_database_password';
const host = process.env.DB_HOST || 'localhost';
const dialect = process.env.DB_DIALECT || 'mysql';

// Create Sequelize instance and connect to the database
const sequelize = new Sequelize(database, username, password, {
    host: host,
    dialect: dialect,
    logging: false, // Set to true to log SQL queries
});

// Load all model definitions from the 'models' folder
const models = {};
const modelsPath = path.join(__dirname, 'models');

fs.readdirSync(modelsPath).forEach((file) => {
    const model = require(path.join(modelsPath, file))(sequelize, Sequelize.DataTypes);
    models[model.name] = model;
});

// Apply associations between models if needed
// For example, models.User.hasMany(models.Post);

// Export the Sequelize instance and models
module.exports = {
    sequelize,
    models,
};
