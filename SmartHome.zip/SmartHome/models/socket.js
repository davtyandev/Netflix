module.exports = (sequelize, Sequelize) => {
    const Socket = sequelize.define('socket', {
        uuid: {
            type: Sequelize.STRING,
            primaryKey: true,
            allowNull: false
        },
        name: {
            type: Sequelize.STRING,
            allowNull: false
        },
        yandexToken: {
            type: Sequelize.STRING,
            allowNull: true // Set to true if the Yandex token is not always required for every socket
        }
    });

    return Socket;
};
