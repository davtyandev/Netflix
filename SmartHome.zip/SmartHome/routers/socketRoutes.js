const express = require('express');
const router = express.Router();
const socketController = require('../controllers/socketController');
const authMiddleware = require('../middleware/authMiddleware');

// Route to get the list of sockets available to the user
router.get('/sockets', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.userId; // Extract the user ID from the authenticated user
        const socketList = await socketController.getSocketList(userId);
        res.json(socketList);
    } catch (error) {
        res.status(500).json({ error: 'Failed to retrieve the list of sockets' });
    }
});

module.exports = router;
