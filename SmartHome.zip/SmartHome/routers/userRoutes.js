const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authController = require('../controllers/authController');

// Route to authenticate a user (user login)
router.post('/login', async (req, res) => {
    try {
        const { login, password } = req.body;

        // Check if the user's credentials are valid
        const isAuthorized = await userController.authorizeUser(login, password);

        if (!isAuthorized) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Generate a JWT token for the authenticated user
        const authToken = await authController.authenticateUser(login, password);

        res.json({ authToken });
    } catch (error) {
        res.status(500).json({ error: 'Failed to authenticate the user' });
    }
});

module.exports = router;
