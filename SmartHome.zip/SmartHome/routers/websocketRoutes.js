const WebSocket = require('ws');
const { handleWebSocketConnection } = require('../controllers/socketController');

// Function to create and configure the WebSocket server
const createWebSocketServer = (server) => {
    const wss = new WebSocket.Server({ server });

    // WebSocket connection event
    wss.on('connection', (ws) => {
        // Handle WebSocket connection using the controller function
        handleWebSocketConnection(ws);
    });
};

module.exports = createWebSocketServer;
