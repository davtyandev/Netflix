const axios = require('axios');

// Yandex API base URL
const baseURL = 'https://api.yandex.com/smart_home/v1/';

// Function to send commands to the Yandex API
async function sendCommandToYandexAPI(token, command) {
    try {
        const headers = {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };

        const response = await axios.post(baseURL + 'user/devices/action', command, { headers });

        if (response.status === 200) {
            return response.data;
        } else {
            throw new Error('Failed to send command to Yandex API');
        }
    } catch (error) {
        throw error;
    }
}

module.exports = {
    sendCommandToYandexAPI
};
